"""Jarvis backend — FastAPI app (runs on Render as an always-on web service).

Endpoints:
- POST /webhook/telegram/{secret} — Telegram pushes updates here (verified twice:
  secret URL path + X-Telegram-Bot-Api-Secret-Token header).
- GET /healthz — Render health check.

On startup: open the database, build the service clients, and (when PUBLIC_URL
is set) register the webhook with Telegram automatically.
"""
from __future__ import annotations

import asyncio
import hmac
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, HTTPException, Request

from app.clients.anthropic_client import ClaudeClient
from app.clients.deepgram_client import DeepgramClient
from app.clients.elevenlabs_client import ElevenLabsClient
from app.clients.telegram_client import TelegramClient
from app.cockpit.page import render_page
from app.cockpit.service import CockpitService
from app.config import get_settings
from app.core.router import JarvisRouter
from app.core.store import SettingsStore
from app.daily12.service import Daily12Service
from app.daily12.trello import TrelloClient
from app.db import get_database
from app.documents.service import DocumentLibrary
from app.documents.storage import make_object_store
from app.heartbeat.calendar_ics import IcsCalendar
from app.heartbeat.emailer import Emailer
from app.heartbeat.jobs import HeartbeatJobs
from app.heartbeat.scheduler import Heartbeat
from app.heartbeat.streaks import Streaks
from app.memory.crypto import PrivateBox
from app.memory.embedder import HashEmbedder, VoyageEmbedder
from app.memory.seed import load_day_one_brain
from app.memory.store import LivingFacts, MemoryStore
from app.private.service import PrivateTrack

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
logger = logging.getLogger("jarvis")


def build_components() -> tuple[JarvisRouter, Heartbeat]:
    settings = get_settings()
    db = get_database(settings.database_url, settings.sqlite_path)

    # Second brain (Milestone 2). Voyage embeds in production; the local
    # embedder keeps everything working before that key exists.
    memory = living = library = None
    if settings.memory_enabled:
        if settings.voyage_api_key:
            embedder = VoyageEmbedder(
                settings.voyage_api_key, model=settings.embed_model, dim=settings.embed_dim
            )
        else:
            logger.warning("VOYAGE_API_KEY not set — using local embeddings (dev quality)")
            embedder = HashEmbedder(dim=settings.embed_dim)
        memory = MemoryStore(db, embedder, PrivateBox(settings.private_room_key))
        living = LivingFacts(db)
        library = DocumentLibrary(
            db,
            memory,
            make_object_store(
                settings.r2_access_key, settings.r2_secret_key,
                settings.r2_bucket, settings.r2_endpoint,
            ),
        )

    # Trello + the Daily 12 (Milestone 3) — activates when the keys exist.
    claude = ClaudeClient(
        settings.anthropic_api_key,
        brain_model=settings.brain_model,
        fast_model=settings.fast_model,
    )
    daily12 = None
    if settings.trello_key and settings.trello_token:
        daily12 = Daily12Service(
            db,
            TrelloClient(settings.trello_key, settings.trello_token),
            claude,
            timezone_default=settings.timezone_default,
        )
    else:
        logger.warning("Trello keys not set — the Daily 12 is dormant until they are")

    telegram = TelegramClient(settings.telegram_bot_token)
    elevenlabs = ElevenLabsClient(
        settings.elevenlabs_api_key,
        voice_id=settings.elevenlabs_voice_id,
        model=settings.elevenlabs_model,
    )

    # The private sobriety track (Milestone 6) — walled off, encrypted, warm.
    private_track = PrivateTrack(
        db,
        claude,
        PrivateBox(settings.private_room_key),
        memory=memory,
        living=living,
    )

    # The heartbeat (Milestone 4).
    jobs = HeartbeatJobs(
        settings=settings,
        db=db,
        telegram=telegram,
        claude=claude,
        elevenlabs=elevenlabs,
        daily12=daily12,
        calendar=IcsCalendar(settings.calendar_ics_url) if settings.calendar_ics_url else None,
        emailer=Emailer(settings.gmail_address, settings.gmail_app_password),
        kiefer_email=settings.kiefer_email,
        private_track=private_track,
    )
    heartbeat = Heartbeat(jobs)

    return JarvisRouter(
        settings=settings,
        db=db,
        memory=memory,
        living=living,
        library=library,
        daily12=daily12,
        heartbeat=jobs,
        on_timezone_change=heartbeat.reschedule,
        private_track=private_track,
        telegram=telegram,
        claude=claude,
        deepgram=DeepgramClient(settings.deepgram_api_key, model=settings.deepgram_model),
        elevenlabs=elevenlabs,
    ), heartbeat


@asynccontextmanager
async def lifespan(app: FastAPI):
    router, heartbeat = build_components()
    await router.db.init()
    app.state.router = router
    app.state.heartbeat = heartbeat

    # Load the Day-One Brain seed (idempotent, versioned).
    if router.memory is not None and router.living is not None:
        try:
            loaded = await load_day_one_brain(router.memory, router.living, SettingsStore(router.db))
            if loaded:
                logger.info("Day-One Brain seeded: %d chunks", loaded)
        except Exception:
            logger.exception("Day-One Brain seeding failed (service continues)")

    settings = router.settings
    if settings.public_url and settings.telegram_bot_token:
        url = f"{settings.public_url.rstrip('/')}/webhook/telegram/{settings.effective_webhook_secret}"
        try:
            await router.telegram.set_webhook(url, settings.effective_webhook_secret)
            logger.info("Telegram webhook registered")
        except Exception:
            logger.exception("Could not register Telegram webhook (will keep serving)")

    # Start the heartbeat — the day runs itself from here.
    if settings.heartbeat_enabled and settings.telegram_bot_token:
        try:
            await heartbeat.start()
        except Exception:
            logger.exception("Heartbeat failed to start (bot still serves)")

    yield

    heartbeat.shutdown()
    await router.db.close()
    for client in (router.telegram, router.claude, router.deepgram, router.elevenlabs):
        try:
            await client.close()
        except Exception:  # noqa: BLE001
            pass


app = FastAPI(title="Jarvis", docs_url=None, redoc_url=None, lifespan=lifespan)

# Strong references to in-flight update tasks — asyncio only weak-refs tasks,
# so without this a message could be garbage-collected mid-handling.
_inflight: set = set()


def _track(task) -> None:
    _inflight.add(task)
    task.add_done_callback(_inflight.discard)


@app.get("/healthz")
async def healthz() -> dict:
    return {"ok": True, "service": "jarvis"}


@app.post("/webhook/telegram/{secret}")
async def telegram_webhook(
    secret: str,
    request: Request,
    x_telegram_bot_api_secret_token: str | None = Header(default=None),
) -> dict:
    router: JarvisRouter = request.app.state.router
    expected = router.settings.effective_webhook_secret
    if not (
        hmac.compare_digest(secret, expected)
        and hmac.compare_digest(x_telegram_bot_api_secret_token or "", expected)
    ):
        raise HTTPException(status_code=403, detail="nope")
    update = await request.json()
    # Answer Telegram fast; do the actual work in the background.
    _track(asyncio.create_task(router.handle_update(update)))
    return {"ok": True}


@app.get("/cockpit/{secret}")
async def cockpit_page(secret: str, request: Request):
    """The Progress Cockpit. Jarvis sends Paul this link; the secret is the key."""
    from fastapi.responses import HTMLResponse

    router: JarvisRouter = request.app.state.router
    if not hmac.compare_digest(secret, router.settings.effective_cockpit_secret):
        raise HTTPException(status_code=404)
    return HTMLResponse(render_page(f"/cockpit/{secret}/data"))


@app.get("/cockpit/{secret}/data")
async def cockpit_data(secret: str, request: Request) -> dict:
    router: JarvisRouter = request.app.state.router
    if not hmac.compare_digest(secret, router.settings.effective_cockpit_secret):
        raise HTTPException(status_code=404)
    service = CockpitService(
        router.db,
        living=router.living,
        calendar=router.heartbeat.calendar if router.heartbeat else None,
        timezone_default=router.settings.timezone_default,
    )
    return await service.gather()


@app.post("/webhook/apple-health")
async def apple_health(request: Request) -> dict:
    """Daily push from the iOS Shortcut: run, sleep, weight, steps, HR/HRV."""
    router: JarvisRouter = request.app.state.router
    payload = await request.json()
    secret = router.settings.apple_health_webhook_secret
    if not secret or not hmac.compare_digest(str(payload.get("secret", "")), secret):
        raise HTTPException(status_code=403, detail="nope")

    from datetime import datetime
    from zoneinfo import ZoneInfo

    import json as _json

    tz = ZoneInfo(await router.store.get("current_timezone", router.settings.timezone_default))
    stat_date = payload.get("date") or datetime.now(tz).date().isoformat()
    await router.db.execute(
        "INSERT INTO health_stats (stat_date, weight_kg, sleep_hours, steps, resting_hr, hrv, raw)"
        " VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            stat_date,
            float(payload.get("weight_kg") or 0),
            float(payload.get("sleep_hours") or 0),
            int(payload.get("steps") or 0),
            int(payload.get("resting_hr") or 0),
            float(payload.get("hrv") or 0),
            _json.dumps(payload)[:4000],
        ),
    )
    run_km = float(payload.get("run_km") or 0)
    recorded_run = False
    if run_km >= 4.5:  # the daily 5k, with GPS wobble tolerance
        day = datetime.fromisoformat(stat_date).date()
        await router.streaks.record("run", day)
        await router.db.execute(
            "INSERT INTO runs (run_date, distance_km, duration_min, source) VALUES (?, ?, ?, 'apple_health')",
            (stat_date, run_km, float(payload.get("run_min") or 0)),
        )
        recorded_run = True
    return {"ok": True, "run_recorded": recorded_run}
